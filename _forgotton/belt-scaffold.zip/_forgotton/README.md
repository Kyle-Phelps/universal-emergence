# _forgotton

The hidden chamber. Early fragments. Not forgotten.