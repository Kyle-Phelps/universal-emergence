# Git Commands Guide

Basic Git rituals:
- `git add .`
- `git commit -m "msg"`
- `git push`